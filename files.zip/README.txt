St. Gabriel Catholic School Student Database

How to use
1) Unzip this bundle.
2) Host the folder on any static web server (GitHub Pages, Netlify, Vercel, or your school's web host).
3) Put your real header image at assets/header.png (replace the placeholder).
4) The student records live in data.json, which was generated from your provided CSV. To update data, replace data.json with a new export in the same format:
   [
     {"name": "Last, First", "homeroom": "1A-Mrs. ...", "gender": "F/M", "birth_date": "M/D/YY"},
     ...
   ]

Features
- Type-ahead search with suggestions (arrow keys to navigate; Enter to select).
- Case-insensitive matching; supports "Last, First" or "First Last" typing.
- Shows Class (Homeroom), DOB (friendly format), Age (auto-calculated), Gender.
- Lightweight, no login required. All data stays client-side.

Notes
- If you need to password-protect the page later, consider hosting behind your school's SSO or adding HTTP auth at the server level.
- If your CSV headers change, update app.js accordingly or regenerate data.json here.